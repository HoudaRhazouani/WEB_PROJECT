function openwindow(){
    window.open('https://gitlab.info.uqam.ca/rhazouani.houda/inf3190-a21-tp1', '_blank', 'toolbar=0,location=0,menubar=0');
}

function openwindowtwo(){
    window.open('https://gitlab.info.uqam.ca/el_falah.hidaya/inf3190-a21-tp1', '_blank', 'toolbar=0,location=0,menubar=0');
}